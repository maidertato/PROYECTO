package proiektua;

import java.util.ArrayList;
import java.util.Iterator;

public class ListaKartak 
{
	//Atributoak 
	private ArrayList <Karta> lista;
	
	//Eraikitzailea 
	public ListaKartak()
	{
		this.lista = new ArrayList<Karta>();
	}
	
	//Beste metodoak
	public Iterator<Karta> getIteradorea()
	{
		return lista.iterator();
	}
	
}
