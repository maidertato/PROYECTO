package proiektua;


public class Partida 
{
	//Atributoak 
	
	private static Partida nirePartida = null; 
	private Jokalaria [] listaJokalariak;
	
	//Eraikitzaitzailea
	
	public Partida ()
	{
		this.listaJokalariak = new Jokalaria[1]; //Jokalari 1 erabiliko dugulako
	}
	
	// gainontzeko metodoak
}
