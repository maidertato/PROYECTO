package proiektua;

public class Jokalaria 
{
	//Atributoak
	
	private String izena;
	private int id;
    private boolean txanda;
    private boolean irabazlea;
    
    private ListaKartak jokalariarenKartak;
    
    
    //Eraikitzailea
    public Jokalaria (String pIzena, int pId, boolean pTxanda, boolean pIrabazlea)
    {
        this.izena = pIzena;
        this.id = pId;
        this.txanda = pTxanda;
        this.irabazlea = pIrabazlea;
        
        this.jokalariarenKartak = new ListaKartak();
        this.botatakoKartak = new ListaKartak();
        this.hartzekoKartak = new ListaKartak();
        
        this.kartakHasieratuJokalariarentzat();
    }

   

	//TODO
    public void inprimatu()
    {
    	System.out.println("Jokalaria zara");
    }

	public String getIzena()
	{
		return izena;
	}

	public int getId()
	{
		return id;
	}

	public boolean getTxanda()
	{
		return txanda;
	}
	
	public boolean getIrabazlea()
	{
		return irabazlea;
	}
	
}
