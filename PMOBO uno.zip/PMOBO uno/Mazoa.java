package proiektua;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class Mazoa {

	private static Mazoa nireMazoa = new Mazoa();
	private ArrayList<Karta> kartak;

	private Mazoa ()
	{
		kartak = new ArrayList<Karta>();
		this.mazoaKargatu();
	}

	private void mazoaKargatu()
	{
		String[] kolorea = {"Gorria", "Berdea", "Horia", "Urdina"};
		String[] deskribapena = {"Bat", "Bi", "Hiru", "Lau", "Bost", "Sei", "Zazpi",
				"Zortzi", "Bederatzi", "Gehi bi", "Gehi Lau", "Norabide Aldaketa",
				"Saltoa", "Kolore aldaketa"};
		int [] balioa = {1,2,3,4,5,6,7,8,9};

		for(String kol : kolorea)
		{
			int posizioa = 0;
			for (String des : deskribapena)
				{
					Karta k = new Karta(kol, des, balioa[posizioa]);
					kartaGehitu(k);
					posizioa ++;
				}
			}
		}

		public static Mazoa getMazoa()
		{
			return nireMazoa;
		}

		private Iterator<Karta> getIteradorea()
		{
			return kartak.iterator();
		}
		
		public void nahastu()
		{
			Collections.shuffle(this.kartak);
		}

		public Karta lapurtu()
		{
			Karta kartaHartu = this.kartak.get(0);
			this.kartak.remove(kartaHartu);
			return kartaHartu;
		}

		public void kartaGehitu(Karta pKarta)
		{
			this.kartak.add(pKarta);
		}
		
		public void mazoaInprimatu()
		{
			for (Karta k : this.kartak)
			{
				k.inprimatu();
			}
		}
		
		private Karta bilatuKarta(String pKolorea, String pDeskribapena)
		{
			boolean aurkitua = false;
			Iterator<Karta> itr = this.getIteradorea();
			Karta kartaBat = null;
			
			while(!aurkitua && itr.hasNext())
			{
				kartaBat = itr.next();
				if(kartaBat.getDeskribapena().equalsIgnoreCase(pDeskribapena) 
						&& kartaBat.getKolorea().equalsIgnoreCase(pKolorea))
				{
					aurkitua = true;
				}
			}
			
			if(!aurkitua)
			{
				kartaBat = null;
				System.out.println("Ez da zure karta aurkitu");
			}
			
			return kartaBat;
		}
		
		public void kartaJarri(String pKolorea, String pDeskribapena, int pPosizioa)
		{
		     Karta kartaBat = bilatuKarta(pKolorea, pDeskribapena);    
		     this.kartak.remove(kartaBat);
		     this.kartak.add(pPosizioa, kartaBat);
		}


	}

