package proiektua;

public abstract class Karta 

{
	//Atributoak
	private String kolorea;
	private String deskribapena;
    protected int balioa;
    private boolean bereTxandaDa;

    //Eraikitzailea
    public Karta(String pKolorea, String pDeskribapena, int pBalioa, boolean pBereTxandaDa)
    {
        this.kolorea = pKolorea;
        this.deskribapena = pDeskribapena;
        this.balioa = pBalioa;
        this.bereTxandaDa = pBereTxandaDa;
    }

    //Beste metodoak
    public abstract void kartaErabili();
    
    public void kartaInprimatu()
    {
    	System.out.println("Kolore " + kolorea + "ko " + balioa + "a. ");
    }

	public String getKolorea()
	{
		return kolorea;
	}

	public String getDeskribapena()
	{
		return deskribapena;
	}

	public double getBalioa()
	{
		return balioa;
	}

}
