package proiektua;

public class KartaArruntza 
{
	//Atributoak
	private int zenbakia;
	
	//Eraikitzailea
	public KartaArrunta(int pZenbakia)
    {
        this.zenbakia = pZenbakia;
    }
	
	//Gainontzeko metodoak 
	
	public boolean botaDaiteke()
	{
		//TODO
		boolean bota = true;
		//TODO
		return (bota);
	}
}
